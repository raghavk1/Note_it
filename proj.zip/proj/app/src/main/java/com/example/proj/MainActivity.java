package com.example.proj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;

import com.example.proj.Activity.InsertNoteActivity;
import com.example.proj.Adapter.NotesAdapter;
import com.example.proj.Model.Notes;
import com.example.proj.ViewModel.NotesViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    FloatingActionButton newNotesBtn;
    NotesViewModel notesViewModel;
    RecyclerView notesRecycler;
    NotesAdapter adapter;


    TextView nofilter,hightolow,lowtohigh;
    List<Notes> filternoteslist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newNotesBtn = findViewById(R.id.newNotesBtn);
        notesRecycler = findViewById(R.id.notesRecycler);

        nofilter = findViewById(R.id.nofilter);
        hightolow = findViewById(R.id.hightolow);
        lowtohigh = findViewById(R.id.lowtohigh);

        nofilter.setBackgroundResource(R.drawable.filter_shape);

        nofilter.setOnClickListener(v -> {
            loadData(0);
            hightolow.setBackgroundResource(R.drawable.filter_shape);
            lowtohigh.setBackgroundResource(R.drawable.filter_shape);
            nofilter.setBackgroundResource(R.drawable.filter_shape_sel);
        });
        hightolow.setOnClickListener(v -> {
            loadData(1);
            hightolow.setBackgroundResource(R.drawable.filter_shape_sel);
            lowtohigh.setBackgroundResource(R.drawable.filter_shape);
            nofilter.setBackgroundResource(R.drawable.filter_shape);
        });
        lowtohigh.setOnClickListener(v -> {
            loadData(2);
            hightolow.setBackgroundResource(R.drawable.filter_shape);
            lowtohigh.setBackgroundResource(R.drawable.filter_shape_sel);
            nofilter.setBackgroundResource(R.drawable.filter_shape);

        });



        notesViewModel = ViewModelProviders.of(this).get(NotesViewModel.class);


        newNotesBtn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, InsertNoteActivity.class));
        });

        notesViewModel.getAllNotes.observe(this, new Observer<List<Notes>>() {
            @Override
            public void onChanged(List<Notes> notes) {
                filternoteslist=notes;
                setAdapter(notes);
            }
        });
    }

    public void loadData(int i) {
        if(i==0) {
            notesViewModel.getAllNotes.observe(this, new Observer<List<Notes>>() {
                @Override
                public void onChanged(List<Notes> notes) {

                    setAdapter(notes);
                    filternoteslist=notes;
                }
            });
        }else if(i==1) {
            notesViewModel.highToLow.observe(this, new Observer<List<Notes>>() {
                @Override
                public void onChanged(List<Notes> notes) {

                    setAdapter(notes);
                    filternoteslist=notes;

                }
            });
        } else if(i==2){
            notesViewModel.lowToHigh.observe(this, new Observer<List<Notes>>() {
                @Override
                public void onChanged(List<Notes> notes) {

                    setAdapter(notes);
                    filternoteslist=notes;

                }
            });
        }
    }

    public void setAdapter(List<Notes> notes){
            notesRecycler.setLayoutManager(new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL));
            adapter=new NotesAdapter(MainActivity.this,notes);
            notesRecycler.setAdapter(adapter);
        }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.search_notes,menu);

        MenuItem menuItem=menu.findItem(R.id.app_bar_search);

        getMenuInflater().inflate(R.menu.delete_menu,menu);
        MenuItem menuItem1=menu.findItem(R.id.ic_share);



        SearchView searchView=(SearchView)menuItem.getActionView();

        searchView.setQueryHint("Search here..");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                NotesFilter(s);
                return false;
            }
        });


        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem menuItem1) {
        Intent intent=new Intent(Intent.ACTION_SEND);
        intent.setType("Text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT,"Check out this cool application");
        intent.putExtra(Intent.EXTRA_TEXT," Share App Via");
        startActivity(Intent.createChooser(intent,"Share Via"));

        return super.onOptionsItemSelected(menuItem1);
    }

    private void NotesFilter(String s) {
        ArrayList<Notes> FilterNames=new ArrayList<>();
        for(Notes notes:this.filternoteslist){
            if(notes.notesTitle.contains(s)||notes.notesSubtitle.contains(s)){
                FilterNames.add(notes);
            }
        }this.adapter.searchNotes(FilterNames);

    }
}
